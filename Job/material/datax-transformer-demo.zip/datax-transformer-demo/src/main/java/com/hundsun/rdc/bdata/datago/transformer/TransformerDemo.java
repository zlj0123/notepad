package com.hundsun.rdc.bdata.datago.transformer;

import com.alibaba.datax.common.element.Record;
import com.alibaba.datax.common.element.StringColumn;
import com.alibaba.datax.common.exception.DataXException;
import com.alibaba.datax.transformer.ComplexTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Map;

public class TransformerDemo extends ComplexTransformer {

    private static final Logger LOG = LoggerFactory.getLogger(TransformerDemo.class);

    public TransformerDemo() {
        super.setTransformerName("hundsun_demo");
    }

    /**
     * @param record  行记录，UDF进行record的处理后，更新相应的record
     * @param map     transformer运行的配置项
     * @param objects transformer函数参数
     */
    @Override
    public Record evaluate(Record record, Map<String, Object> map, Object... objects) {
        LOG.info("start to hundsun_demo transformer function");
        int columnIndex;
        String replaceString;
        try {
            if (objects.length != 2) {
                throw new RuntimeException("hundsun_demo transformer paras must be 2");
            }

            columnIndex = (Integer) objects[0];
            replaceString = (String) objects[1];
        } catch (Exception e) {
            throw DataXException.asDataXException(TransformerDemoErrorCode.TRANSFORMER_ILLEGAL_PARAMETER, "paras:" + Arrays.asList(objects) + " => " + e.getMessage());
        }

        record.setColumn(columnIndex, new StringColumn(replaceString));
        LOG.info("end to hundsun_demo transformer function");
        return record;
    }
}
