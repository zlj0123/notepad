package com.hundsun.rdc.bdata.datago.transformer;

import com.alibaba.datax.common.spi.ErrorCode;

public enum TransformerDemoErrorCode implements ErrorCode {

    TRANSFORMER_CONFIGURATION_ERROR("TransformerErrorCode-04", "Transformer configuration error"),
    TRANSFORMER_ILLEGAL_PARAMETER("TransformerErrorCode-05", "Transformer parameter illegal"),
    TRANSFORMER_RUN_EXCEPTION("TransformerErrorCode-06", "Transformer run exception"),
    ;

    private final String code;

    private final String description;

    TransformerDemoErrorCode(String code, String description) {
        this.code = code;
        this.description = description;
    }

    @Override
    public String getCode() {
        return this.code;
    }

    @Override
    public String getDescription() {
        return this.description;
    }

    @Override
    public String toString() {
        return String.format("Code:[%s], Description:[%s]. ", this.code,
                this.description);
    }
}
